// app/components/TourFinder.tsx
'use client';
import { useState, useMemo } from 'react';
import Link from 'next/link';

// ========================================
// TYPES
// ========================================
interface Tour {
  title: string;
  slug: string;
  price: number;
  duration: string;
  rating: number;
  reviewCount: number;
  gygUrl: string;
  provider: string;
  image?: string;
}

interface Answers {
  time: string | null;
  group: string | null;
  experience: string | null;
  budget: string | null;
}

// ========================================
// HELPERS
// ========================================
function parseDurationToMinutes(duration: string | null): number | null {
  if (!duration) return null;
  const d = duration.toLowerCase().trim();

  const hoursMatch = d.match(/([\d.]+)\s*(?:hours?|hrs?|h)/);
  if (hoursMatch) {
    const hours = parseFloat(hoursMatch[1]);
    const addMinMatch = d.match(/(\d+)\s*(?:minutes?|mins?|m)/);
    const addMin = addMinMatch ? parseInt(addMinMatch[1]) : 0;
    return Math.round(hours * 60 + addMin);
  }

  const minMatch = d.match(/([\d.]+)\s*(?:minutes?|mins?|m)/);
  if (minMatch) return Math.round(parseFloat(minMatch[1]));

  if (d.includes('full day') || d.includes('full-day')) return 480;
  if (d.includes('half day') || d.includes('half-day')) return 240;

  const rangeMatch = d.match(/([\d.]+)\s*-\s*([\d.]+)\s*(?:hours?|hrs?)/);
  if (rangeMatch) return Math.round(((parseFloat(rangeMatch[1]) + parseFloat(rangeMatch[2])) / 2) * 60);

  return null;
}

function classifyTour(title: string) {
  const t = title.toLowerCase();

  let tourType = 'standard';
  if (t.includes('underground') || t.includes('hypogeum')) tourType = 'underground';
  else if (t.includes('night') || t.includes('after dark') || t.includes('moonlight') || t.includes('twilight')) tourType = 'night';
  else if (t.includes('arena') && !t.includes('optional')) tourType = 'arena';
  else if (t.includes('vatican') || t.includes('sistine')) tourType = 'combo-vatican';
  else if (t.includes('forum') || t.includes('palatine')) tourType = 'combo-forum';

  let format = 'guided';
  if (t.includes('audio') || t.includes('audioapp') || t.includes('audio guide')) format = 'audio-guide';
  else if (t.includes('private') || t.includes('vip')) format = 'private';
  else if (t.includes('self-guided') || t.includes('self guided')) format = 'self-guided';

  let groupSize = 'standard';
  if (t.includes('small group') || t.includes('small-group') || t.match(/max\s*\d/)) groupSize = 'small-group';
  else if (t.includes('private') || t.includes('vip')) groupSize = 'private';

  return { tourType, format, groupSize };
}

function formatDuration(duration: string | null): string {
  if (!duration) return '';
  const mins = parseDurationToMinutes(duration);
  if (!mins) return duration;
  if (mins < 60) return `${mins} min`;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
}

function formatReviewCount(count: number): string {
  if (count >= 1000) return `${(count / 1000).toFixed(1)}k`;
  return count.toString();
}

// ========================================
// QUESTIONS CONFIG
// ========================================
const QUESTIONS = [
  {
    id: 'time',
    title: 'How much time do you have?',
    subtitle: 'This helps us match the right tour length for your schedule.',
    options: [
      { value: 'quick', label: '1–2 hours', desc: 'A focused visit', icon: '⚡' },
      { value: 'half', label: 'Half day', desc: '3–4 hours to explore', icon: '🕐' },
      { value: 'full', label: 'Full day', desc: 'Combine with other sites', icon: '☀️' },
    ],
  },
  {
    id: 'group',
    title: "Who's coming with you?",
    subtitle: "We'll find tours that fit your group perfectly.",
    options: [
      { value: 'couple', label: 'Solo or couple', desc: 'Just us', icon: '👫' },
      { value: 'family', label: 'Family with kids', desc: 'Kid-friendly options', icon: '👨‍👩‍👧‍👦' },
      { value: 'friends', label: 'Group of friends', desc: 'Fun group experience', icon: '👥' },
      { value: 'private', label: 'Private experience', desc: 'Just our group, our pace', icon: '🎩' },
    ],
  },
  {
    id: 'experience',
    title: 'What kind of experience do you want?',
    subtitle: 'From a quick look to the deepest access — your call.',
    options: [
      { value: 'basic', label: 'Just see the Colosseum', desc: 'The classic visit — first and second levels', icon: '🏛️' },
      { value: 'deeper', label: 'Go where most tourists can\'t', desc: 'Underground chambers or arena floor', icon: '🔦' },
      { value: 'complete', label: 'The full ancient Rome story', desc: 'Colosseum + Forum + Palatine Hill', icon: '📜' },
      { value: 'combo', label: 'Colosseum + Vatican in one day', desc: 'Two icons, one trip', icon: '⛪' },
    ],
  },
  {
    id: 'budget',
    title: 'What about budget?',
    subtitle: 'All tours include skip-the-line access.',
    options: [
      { value: 'value', label: 'Best value', desc: 'Great experience, smart price', icon: '💚' },
      { value: 'flexible', label: "I'm flexible", desc: 'Show me the best-rated', icon: '⭐' },
      { value: 'premium', label: 'Money is not an issue', desc: 'VIP and private options', icon: '💎' },
    ],
  },
];

// ========================================
// FILTERING LOGIC
// ========================================
function filterTours(tours: Tour[], answers: Answers): Tour[] {
  let filtered = tours.filter(t => t.price > 0 && t.rating > 0);

  // Classify all tours
  const classified = filtered.map(t => ({
    ...t,
    ...classifyTour(t.title),
    minutes: parseDurationToMinutes(t.duration),
  }));

  let results = classified;

  // FILTER BY TIME
  if (answers.time === 'quick') {
    results = results.filter(t => t.minutes && t.minutes <= 150);
  } else if (answers.time === 'half') {
    results = results.filter(t => t.minutes && t.minutes > 90 && t.minutes <= 300);
  } else if (answers.time === 'full') {
    results = results.filter(t => t.minutes && t.minutes > 240 || t.tourType === 'combo-vatican');
  }

  // FILTER BY GROUP
  if (answers.group === 'family') {
    // Exclude underground (kids often can't enter)
    results = results.filter(t => t.tourType !== 'underground' && t.tourType !== 'night');
  } else if (answers.group === 'private') {
    results = results.filter(t => t.format === 'private');
  }

  // FILTER BY EXPERIENCE
  if (answers.experience === 'basic') {
    results = results.filter(t =>
      t.tourType === 'standard' || t.tourType === 'combo-forum'
    );
  } else if (answers.experience === 'deeper') {
    results = results.filter(t =>
      t.tourType === 'underground' || t.tourType === 'arena' || t.tourType === 'night'
    );
  } else if (answers.experience === 'complete') {
    results = results.filter(t =>
      t.tourType === 'combo-forum' || (t.minutes && t.minutes >= 150)
    );
    // Exclude Vatican combos
    results = results.filter(t => t.tourType !== 'combo-vatican');
  } else if (answers.experience === 'combo') {
    results = results.filter(t => t.tourType === 'combo-vatican');
  }

  // SORT BY BUDGET
  if (answers.budget === 'value') {
    results.sort((a, b) => {
      // Prioritize: good rating + low price
      const scoreA = (a.rating || 0) * 10 - (a.price / 20);
      const scoreB = (b.rating || 0) * 10 - (b.price / 20);
      return scoreB - scoreA;
    });
  } else if (answers.budget === 'flexible') {
    results.sort((a, b) => {
      // Prioritize: highest rating, then most reviews
      if (b.rating !== a.rating) return (b.rating || 0) - (a.rating || 0);
      return (b.reviewCount || 0) - (a.reviewCount || 0);
    });
  } else if (answers.budget === 'premium') {
    results.sort((a, b) => b.price - a.price);
  }

  // Deduplicate by GYG URL (some tours share the same GYG listing)
  const seen = new Set();
  results = results.filter(t => {
    const gygId = t.gygUrl.match(/t(\d+)/)?.[1] || t.gygUrl;
    if (seen.has(gygId)) return false;
    seen.add(gygId);
    return true;
  });

  return results.slice(0, 3);
}

// ========================================
// WHY THIS TOUR — explanation generator
// ========================================
function getWhyText(tour: Tour & { tourType: string; format: string }, answers: Answers): string {
  const parts: string[] = [];

  if (answers.experience === 'deeper' && tour.tourType === 'underground') {
    parts.push('Includes exclusive underground access where gladiators waited before combat');
  } else if (answers.experience === 'deeper' && tour.tourType === 'arena') {
    parts.push('Walk on the arena floor where gladiators fought — most visitors only see it from above');
  } else if (answers.experience === 'combo') {
    parts.push('Combines Colosseum and Vatican in one efficient day');
  } else if (answers.experience === 'complete') {
    parts.push('Covers the Colosseum, Roman Forum, and Palatine Hill — the full ancient Rome experience');
  }

  if (answers.group === 'private' && tour.format === 'private') {
    parts.push('Private tour — just your group, at your pace');
  }

  if (tour.reviewCount >= 1000) {
    parts.push(`${formatReviewCount(tour.reviewCount)} verified reviews`);
  }

  if (tour.rating >= 4.8) {
    parts.push(`${tour.rating}/5 rating`);
  }

  return parts.join('. ') + '.';
}

// ========================================
// COMPONENT: Option Card
// ========================================
function OptionCard({ option, selected, onClick }: {
  option: { value: string; label: string; desc: string; icon: string };
  selected: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: '16px',
        width: '100%',
        padding: '18px 20px',
        border: selected ? '2px solid #e91e63' : '2px solid #e0e0e0',
        borderRadius: '12px',
        background: selected ? 'rgba(233,30,99,0.06)' : '#fff',
        cursor: 'pointer',
        textAlign: 'left',
        transition: 'all 0.2s ease',
        boxShadow: selected ? '0 4px 12px rgba(233,30,99,0.15)' : 'none',
      }}
    >
      <span style={{ fontSize: '28px', flexShrink: 0 }}>{option.icon}</span>
      <div>
        <div style={{
          fontWeight: 700,
          fontSize: '1.05rem',
          color: '#1a1a1a',
          marginBottom: '2px',
        }}>
          {option.label}
        </div>
        <div style={{
          fontSize: '0.9rem',
          color: '#666',
        }}>
          {option.desc}
        </div>
      </div>
      {selected && (
        <span style={{
          marginLeft: 'auto',
          color: '#e91e63',
          fontSize: '22px',
          flexShrink: 0,
        }}>✓</span>
      )}
    </button>
  );
}

// ========================================
// COMPONENT: Result Card
// ========================================
function ResultCard({ tour, rank, answers }: {
  tour: Tour & { tourType: string; format: string };
  rank: number;
  answers: Answers;
}) {
  const whyText = getWhyText(tour, answers);

  return (
    <div style={{
      border: rank === 1 ? '2px solid #e91e63' : '1px solid #e0e0e0',
      borderRadius: '16px',
      overflow: 'hidden',
      background: '#fff',
      boxShadow: rank === 1 ? '0 8px 24px rgba(233,30,99,0.12)' : '0 2px 8px rgba(0,0,0,0.06)',
      transition: 'transform 0.2s ease',
    }}>
      {rank === 1 && (
        <div style={{
          background: '#e91e63',
          color: '#fff',
          padding: '6px 16px',
          fontSize: '0.8rem',
          fontWeight: 700,
          textAlign: 'center',
          letterSpacing: '0.5px',
          textTransform: 'uppercase',
        }}>
          🏆 Best Match for You
        </div>
      )}

      <div style={{ padding: '20px' }}>
        {/* Title */}
        <h3 style={{
          fontSize: '1.1rem',
          fontWeight: 700,
          color: '#1a1a1a',
          marginBottom: '12px',
          lineHeight: 1.3,
        }}>
          {tour.title}
        </h3>

        {/* Stats row */}
        <div style={{
          display: 'flex',
          flexWrap: 'wrap',
          gap: '12px',
          marginBottom: '14px',
          fontSize: '0.9rem',
          color: '#444',
        }}>
          <span>⭐ {tour.rating}/5 ({formatReviewCount(tour.reviewCount)} reviews)</span>
          <span>💰 ${tour.price}</span>
          {tour.duration && <span>⏱️ {formatDuration(tour.duration)}</span>}
        </div>

        {/* Why this tour */}
        <p style={{
          fontSize: '0.9rem',
          color: '#555',
          lineHeight: 1.5,
          marginBottom: '16px',
          padding: '10px 14px',
          background: '#f8f8f8',
          borderRadius: '8px',
          borderLeft: '3px solid #e91e63',
        }}>
          {whyText}
        </p>

        {/* CTA buttons */}
        <div style={{
          display: 'flex',
          gap: '10px',
          flexWrap: 'wrap',
        }}>
          <a
            href={tour.gygUrl}
            target="_blank"
            rel="noopener noreferrer"
            style={{
              display: 'inline-block',
              padding: '12px 24px',
              background: '#e91e63',
              color: '#fff',
              borderRadius: '8px',
              fontWeight: 700,
              fontSize: '0.95rem',
              textDecoration: 'none',
              textAlign: 'center',
              flex: 1,
              minWidth: '140px',
              transition: 'background 0.2s',
            }}
          >
            Check Availability
          </a>
          <Link
            href={`/tour/${tour.slug}`}
            style={{
              display: 'inline-block',
              padding: '12px 24px',
              background: '#fff',
              color: '#e91e63',
              border: '2px solid #e91e63',
              borderRadius: '8px',
              fontWeight: 600,
              fontSize: '0.95rem',
              textDecoration: 'none',
              textAlign: 'center',
              flex: 1,
              minWidth: '140px',
            }}
          >
            Read Full Review
          </Link>
        </div>
      </div>
    </div>
  );
}

// ========================================
// MAIN COMPONENT
// ========================================
export default function TourFinder({ tours }: { tours: Tour[] }) {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Answers>({
    time: null,
    group: null,
    experience: null,
    budget: null,
  });
  const [showResults, setShowResults] = useState(false);

  const currentQuestion = QUESTIONS[step];
  const questionKeys: (keyof Answers)[] = ['time', 'group', 'experience', 'budget'];

  const handleSelect = (value: string) => {
    const key = questionKeys[step];
    const newAnswers = { ...answers, [key]: value };
    setAnswers(newAnswers);

    // Auto-advance after short delay
    setTimeout(() => {
      if (step < QUESTIONS.length - 1) {
        setStep(step + 1);
      } else {
        setShowResults(true);
      }
    }, 300);
  };

  const handleBack = () => {
    if (showResults) {
      setShowResults(false);
    } else if (step > 0) {
      setStep(step - 1);
    }
  };

  const handleRestart = () => {
    setStep(0);
    setAnswers({ time: null, group: null, experience: null, budget: null });
    setShowResults(false);
  };

  // Filter tours based on answers
  const results = useMemo(() => {
    if (!showResults) return [];
    return filterTours(tours, answers);
  }, [showResults, tours, answers]);

  // No results fallback
  const fallbackResults = useMemo(() => {
    if (results.length > 0) return results;
    // Relax filters: just sort by rating
    const sorted = [...tours]
      .filter(t => t.price > 0 && t.rating > 0)
      .sort((a, b) => (b.rating || 0) - (a.rating || 0));
    // Deduplicate
    const seen = new Set();
    return sorted.filter(t => {
      const gygId = t.gygUrl.match(/t(\d+)/)?.[1] || t.gygUrl;
      if (seen.has(gygId)) return false;
      seen.add(gygId);
      return true;
    }).slice(0, 3).map(t => ({ ...t, ...classifyTour(t.title), minutes: parseDurationToMinutes(t.duration) }));
  }, [results, tours]);

  const displayResults = results.length > 0 ? results : fallbackResults;

  return (
    <div style={{
      maxWidth: '700px',
      margin: '0 auto',
      padding: '40px 20px 80px 20px',
    }}>
      {/* Header */}
      <div style={{ textAlign: 'center', marginBottom: '40px' }}>
        <h1 style={{
          fontSize: 'clamp(1.8rem, 4vw, 2.5rem)',
          fontWeight: 800,
          color: '#1a1a1a',
          marginBottom: '12px',
          lineHeight: 1.2,
        }}>
          Find Your Perfect Colosseum Tour
        </h1>
        <p style={{
          fontSize: '1.05rem',
          color: '#666',
          maxWidth: '500px',
          margin: '0 auto',
          lineHeight: 1.5,
        }}>
          Answer {QUESTIONS.length} quick questions and we'll match you with the best tour from {tours.length} options.
        </p>
      </div>

      {/* Progress bar */}
      {!showResults && (
        <div style={{ marginBottom: '32px' }}>
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            marginBottom: '8px',
          }}>
            <span style={{ fontSize: '0.85rem', color: '#888' }}>
              Question {step + 1} of {QUESTIONS.length}
            </span>
            <span style={{ fontSize: '0.85rem', color: '#888' }}>
              {Math.round(((step + 1) / QUESTIONS.length) * 100)}%
            </span>
          </div>
          <div style={{
            height: '6px',
            background: '#eee',
            borderRadius: '3px',
            overflow: 'hidden',
          }}>
            <div style={{
              height: '100%',
              width: `${((step + 1) / QUESTIONS.length) * 100}%`,
              background: '#e91e63',
              borderRadius: '3px',
              transition: 'width 0.4s ease',
            }} />
          </div>
        </div>
      )}

      {/* Question */}
      {!showResults && currentQuestion && (
        <div>
          <h2 style={{
            fontSize: '1.4rem',
            fontWeight: 700,
            color: '#1a1a1a',
            marginBottom: '6px',
          }}>
            {currentQuestion.title}
          </h2>
          <p style={{
            fontSize: '0.95rem',
            color: '#777',
            marginBottom: '24px',
          }}>
            {currentQuestion.subtitle}
          </p>

          <div style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '10px',
          }}>
            {currentQuestion.options.map(option => (
              <OptionCard
                key={option.value}
                option={option}
                selected={answers[questionKeys[step] as keyof Answers] === option.value}
                onClick={() => handleSelect(option.value)}
              />
            ))}
          </div>

          {/* Back button */}
          {step > 0 && (
            <button
              onClick={handleBack}
              style={{
                marginTop: '20px',
                padding: '10px 20px',
                background: 'none',
                border: 'none',
                color: '#888',
                cursor: 'pointer',
                fontSize: '0.9rem',
              }}
            >
              ← Back
            </button>
          )}
        </div>
      )}

      {/* Results */}
      {showResults && (
        <div>
          <div style={{ textAlign: 'center', marginBottom: '30px' }}>
            <h2 style={{
              fontSize: '1.6rem',
              fontWeight: 800,
              color: '#1a1a1a',
              marginBottom: '8px',
            }}>
              {results.length > 0
                ? `We found ${displayResults.length} perfect matches for you`
                : `Here are our top recommendations`
              }
            </h2>
            <p style={{
              fontSize: '0.95rem',
              color: '#777',
            }}>
              Based on your preferences, sorted by best fit.
            </p>
          </div>

          {/* Your selections summary */}
          <div style={{
            display: 'flex',
            flexWrap: 'wrap',
            gap: '8px',
            marginBottom: '24px',
            justifyContent: 'center',
          }}>
            {QUESTIONS.map((q, i) => {
              const answer = answers[questionKeys[i]];
              const option = q.options.find(o => o.value === answer);
              if (!option) return null;
              return (
                <span
                  key={q.id}
                  style={{
                    padding: '6px 14px',
                    background: '#f5f5f5',
                    borderRadius: '20px',
                    fontSize: '0.82rem',
                    color: '#555',
                  }}
                >
                  {option.icon} {option.label}
                </span>
              );
            })}
          </div>

          {/* Tour cards */}
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '20px',
            marginBottom: '30px',
          }}>
            {displayResults.map((tour, i) => (
              <ResultCard
                key={tour.slug}
                tour={tour as any}
                rank={i + 1}
                answers={answers}
              />
            ))}
          </div>

          {/* Actions */}
          <div style={{
            display: 'flex',
            gap: '12px',
            justifyContent: 'center',
            flexWrap: 'wrap',
          }}>
            <button
              onClick={handleRestart}
              style={{
                padding: '12px 28px',
                background: '#fff',
                border: '2px solid #e91e63',
                color: '#e91e63',
                borderRadius: '8px',
                fontWeight: 600,
                cursor: 'pointer',
                fontSize: '0.95rem',
              }}
            >
              Start Over
            </button>
            <Link
              href="/tours/colosseum"
              style={{
                padding: '12px 28px',
                background: '#f5f5f5',
                border: '2px solid #ddd',
                color: '#555',
                borderRadius: '8px',
                fontWeight: 600,
                textDecoration: 'none',
                fontSize: '0.95rem',
              }}
            >
              Browse All Tours
            </Link>
          </div>

          {/* Methodology note */}
          <div style={{
            marginTop: '40px',
            padding: '16px 20px',
            background: '#fafafa',
            borderRadius: '10px',
            borderTop: '2px solid #eee',
          }}>
            <p style={{
              fontSize: '0.8rem',
              color: '#999',
              lineHeight: 1.6,
              margin: 0,
            }}>
              Recommendations based on {tours.length} Colosseum tours tracked by Intercoper. 
              Prices, ratings, and availability updated twice weekly from GetYourGuide. 
              Tour Finder matches your preferences to tour type, duration, group format, and price — 
              then ranks by verified visitor ratings. We earn a commission when you book through our links, 
              at no extra cost to you.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
