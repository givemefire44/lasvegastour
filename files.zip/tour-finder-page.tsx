// app/tour-finder/page.tsx
import { createClient } from '@sanity/client';
import TourFinder from '../components/TourFinder';

const client = createClient({
  projectId: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID,
  dataset: process.env.NEXT_PUBLIC_SANITY_DATASET || 'production',
  apiVersion: '2024-01-01',
  useCdn: true,
});

export const metadata = {
  title: 'Colosseum Tour Finder — Find Your Perfect Tour in 30 Seconds',
  description: 'Answer 4 simple questions and we\'ll match you with the best Colosseum tour based on your time, group, interests, and budget. Data from 76 tours and 1,800+ real reviews.',
  alternates: {
    canonical: 'https://colosseumroman.com/tour-finder',
  },
};

async function getTours() {
  return await client.fetch(`
    *[_type == "post" && defined(tourInfo.price) && defined(getYourGuideUrl) && !(_id in path("drafts.**"))] | order(getYourGuideData.reviewCount desc) {
      title,
      "slug": slug.current,
      "price": tourInfo.price,
      "duration": tourInfo.duration,
      "rating": getYourGuideData.rating,
      "reviewCount": getYourGuideData.reviewCount,
      "gygUrl": getYourGuideUrl,
      "provider": getYourGuideData.provider,
      "image": mainImage.asset->url
    }
  `);
}

export default async function TourFinderPage() {
  const tours = await getTours();

  const schemaMarkup = {
    "@context": "https://schema.org",
    "@type": "WebApplication",
    "name": "Colosseum Tour Finder",
    "url": "https://colosseumroman.com/tour-finder",
    "description": "Interactive tool to find the best Colosseum tour based on your preferences. Analyzes 76 tours with data from 1,800+ verified reviews.",
    "applicationCategory": "TravelApplication",
    "operatingSystem": "Any",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    },
    "author": {
      "@type": "Organization",
      "@id": "https://intercoper.com/#organization",
      "name": "Intercoper"
    }
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaMarkup) }}
      />
      <TourFinder tours={tours} />
    </>
  );
}
